pedigrees <- read.table(pedfile,header=T, sep="\t")
Gpool <- read.table(bodyfile,header=T,sep="\t")
print(pedigrees)
print(Gpool)
